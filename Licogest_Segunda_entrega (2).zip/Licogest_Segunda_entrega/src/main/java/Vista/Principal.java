package Vista;

import Persistencia.Cliente;
import Persistencia.Domiciliario;
import Persistencia.Pedido;
import Logica.Productos;
import java.util.ArrayList;
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numeroDePedido = 1;
        ArrayList<Cliente> listaClientes = new ArrayList<>();
        ArrayList<Productos> listaproductos = new ArrayList<>();
        ArrayList<Domiciliario> listaDomiciliarios = new ArrayList<>();
        ArrayList<Pedido> pedidos = new ArrayList<>();

        while (true) {
            System.out.println("Menú:");
            System.out.println("1. Crear Cliente");
            System.out.println("2. Crear Domiciliario");
            System.out.println("3. Consulta produtos");
            System.out.println("4. Realizar pedido");
            System.out.println("0. Salir");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("Crear Cliente:");

                    // Solicitar información del cliente al usuario
                    System.out.println("Nombre del cliente: ");
                    String nombre = scanner.next();
                    System.out.println("Apellido del cliente: ");
                    String apellido = scanner.next();
                    System.out.println("ID del cliente: ");
                    String id = scanner.next();
                    System.out.println("Número de celular del cliente: ");
                    String celular = scanner.next();
                    System.out.println("Dirección del cliente: ");
                    String direccion = scanner.next();
                    System.out.println("Método de pago del cliente: ");
                    String metodoPago = scanner.next();

                    // Crear un objeto Cliente con la información proporcionada
                    Cliente nuevoCliente = new Cliente(nombre, apellido, id, celular, direccion, metodoPago);

                    // Agregar el cliente al ArrayList de clientes
                    listaClientes.add(nuevoCliente);

                    System.out.println("Cliente creado con éxito.");
                    break;

                case 2:
                    System.out.println("Crear Domiciliario:");

                    // Solicitar información del domiciliario al usuario
                    System.out.println("Nombre del domiciliario: ");
                    String nombreDomiciliario = scanner.next();
                    System.out.println("Apellido del domiciliario: ");
                    String apellidoDomiciliario = scanner.next();
                    System.out.println("ID del domiciliario: ");
                    String idDomiciliario = scanner.next();
                    System.out.println("Número de celular del domiciliario: ");
                    String celularDomiciliario = scanner.next();
                    System.out.println("Dirección del domiciliario: ");
                    String direccionDomiciliario = scanner.next();
                    System.out.println("¿Tiene vehículo propio? (true/false): ");
                    boolean vehiculoPropioDomiciliario = scanner.nextBoolean();
                    System.out.println("¿Tiene vehículo empresarial? (true/false): ");
                    boolean vehiculoEmpresarialDomiciliario = scanner.nextBoolean();

                    // Crear el objeto Domiciliario con la información proporcionada
                    Domiciliario nuevoDomiciliario = new Domiciliario(nombreDomiciliario, apellidoDomiciliario, idDomiciliario, celularDomiciliario, direccionDomiciliario, vehiculoPropioDomiciliario, vehiculoEmpresarialDomiciliario);

                    // Agregar el domiciliario al ArrayList de domiciliarios
                    listaDomiciliarios.add(nuevoDomiciliario);

                    System.out.println("Domiciliario creado con éxito.");
                    break;

                case 3:
                    System.out.println("Gestionar Productos:");
                    System.out.println("1. Mostrar productos");
                    System.out.println("2. Agregar producto");
                    System.out.println("3. Eliminar producto");
                    System.out.println("4. Cambiar producto");
                    System.out.print("Seleccione una opción ");

                    int opcionGestionProductos = scanner.nextInt();

                    switch (opcionGestionProductos) {
                        case 1:
                            System.out.println("Mostrar inventario:");
                            // Mostrar inventario de productos
                            if (listaproductos.isEmpty()) {
                                System.out.println("El inventario de productos está vacío.");
                            } else {
                                System.out.println("Inventario de Productos:");
                                for (int i = 0; i < listaproductos.size(); i++) {
                                    Productos producto = listaproductos.get(i);
                                    System.out.println((i + 1) + ". Nombre: " + producto.getNom());
                                    System.out.println("   Precio: " + producto.getPrecio());
                                    System.out.println("   Cantidad: " + producto.getCantidad());
                                    System.out.println("   Marca: " + producto.getMarca());
                                    System.out.println("   Mililitros: " + producto.getMililitros());
                                    System.out.println("------------------------------");
                                }
                            }
                            break;

                        case 2:
                            // Solicitar información sobre el nuevo producto al usuario
                            System.out.println("Nombre del nuevo producto: ");
                            String nom = scanner.next();
                            System.out.println("Precio del nuevo producto: ");
                            double precio = scanner.nextDouble();
                            System.out.println("Cantidad del nuevo producto: ");
                            int cantidad = scanner.nextInt();
                            System.out.println("Marca del nuevo producto: ");
                            String marca = scanner.next();
                            System.out.println("Mililitros del nuevo producto: ");
                            int mililitros = scanner.nextInt();

                            Productos nuevoProducto = new Productos(nom, precio, cantidad, marca, mililitros);

                            listaproductos.add(nuevoProducto);

                            System.out.println("El nuevo producto se ha agregado al inventario.");
                            break;

                        case 3:
                            if (listaproductos.isEmpty()) {
                                System.out.println("El inventario de productos está vacío. No hay productos para eliminar.");
                            } else {
                                // Mostrar los productos disponibles para que el usuario seleccione cuál eliminar
                                System.out.println("Productos Disponibles:");
                                for (int i = 0; i < listaproductos.size(); i++) {
                                    System.out.println((i + 1) + ". " + listaproductos.get(i).getNom());
                                }

                                // Solicitar al usuario que seleccione el número del producto a eliminar
                                System.out.print("Seleccione el número del producto a eliminar: ");
                                int numeroProductoAEliminar = scanner.nextInt();

                                // Verificar si el número seleccionado es válido
                                if (numeroProductoAEliminar >= 1 && numeroProductoAEliminar <= listaproductos.size()) {
                                    // Eliminar el producto seleccionado del inventario
                                    listaproductos.remove(numeroProductoAEliminar - 1);
                                    System.out.println("El producto ha sido eliminado del inventario.");
                                } else {
                                    System.out.println("Número de producto no válido. No se ha eliminado ningún producto.");
                                }
                            }
                            break;

                        case 4:
                            System.out.println("Cambiar producto en el inventario:");
                            if (listaproductos.isEmpty()) {
                                System.out.println("El inventario de productos está vacío. No hay productos para cambiar.");
                            } else {
                                // Mostrar los productos disponibles para que el usuario seleccione cuál cambiar
                                System.out.println("Productos Disponibles:");
                                for (int i = 0; i < listaproductos.size(); i++) {
                                    System.out.println((i + 1) + ". " + listaproductos.get(i).getNom());
                                }

                                // Solicitar al usuario que seleccione el número del producto a cambiar
                                System.out.print("Seleccione el número del producto a cambiar: ");
                                int numeroProductoACambiar = scanner.nextInt();

                                // Verificar si el número seleccionado es válido
                                if (numeroProductoACambiar >= 1 && numeroProductoACambiar <= listaproductos.size()) {
                                    // Obtener el producto actual
                                    Productos productoActual = listaproductos.get(numeroProductoACambiar - 1);

                                    // Solicitar al usuario que ingrese los nuevos detalles del producto
                                    System.out.println("Nuevo nombre del producto: ");
                                    String nuevoNombre = scanner.next();
                                    System.out.println("Nuevo precio del producto: ");
                                    double nuevoPrecio = scanner.nextDouble();
                                    System.out.println("Nueva cantidad del producto: ");
                                    int nuevaCantidad = scanner.nextInt();
                                    System.out.println("Nueva marca del producto: ");
                                    String nuevaMarca = scanner.next();
                                    System.out.println("Nuevos mililitros del producto: ");
                                    int nuevosMililitros = scanner.nextInt();

                                    // Actualizar los detalles del producto
                                    productoActual.setNom(nuevoNombre);
                                    productoActual.setPrecio(nuevoPrecio);
                                    productoActual.setCantidad(nuevaCantidad);
                                    productoActual.setMarca(nuevaMarca);
                                    productoActual.setMililitros(nuevosMililitros);

                                    System.out.println("El producto ha sido cambiado en el inventario.");
                                } else {
                                    System.out.println("Número de producto no válido. No se ha cambiado ningún producto.");
                                }
                            }
                            break;
                        default:
                            System.out.println("Opción no válida.");
                    }
                    break;

                case 4:
                    System.out.println("Realizar Pedido:");

                    // Mostrar una lista de productos disponibles
                    System.out.println("Productos disponibles:");
                    for (int i = 0; i < listaproductos.size(); i++) {
                        System.out.println(i + ". " + listaproductos.get(i).getNom());
                    }

                    // Permitir al usuario seleccionar un producto
                    System.out.println("Seleccione un producto (ingrese el número): ");
                    int indiceProducto = scanner.nextInt();
                    if (indiceProducto < 0 || indiceProducto >= listaproductos.size()) {
                        System.out.println("Número de producto no válido.");
                        break;
                    }

                    // Mostrar una lista de clientes disponibles
                    System.out.println("Clientes disponibles:");
                    for (int i = 0; i < listaClientes.size(); i++) {
                        System.out.println(i + ". " + listaClientes.get(i).getNombre());
                    }

                    // Permitir al usuario seleccionar un cliente
                    System.out.println("Seleccione un cliente (ingrese el número): ");
                    int indiceCliente = scanner.nextInt();
                    if (indiceCliente < 0 || indiceCliente >= listaClientes.size()) {
                        System.out.println("Número de cliente no válido.");
                        break;
                    }

                    // Solicitar el valor del domicilio
                    System.out.print("Ingrese el valor del domicilio: ");
                    double costoDomicilio = scanner.nextDouble();

                    // Obtener el producto y cliente seleccionados
                    Productos productoSeleccionado = listaproductos.get(indiceProducto);
                    Cliente clienteSeleccionado = listaClientes.get(indiceCliente);
                    break;

                case 0:
                    scanner.close();
                    System.out.println("Saliendo del programa.");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
                    break;
            }
        }
    }
}
