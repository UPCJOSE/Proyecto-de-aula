
package Persistencia;

import Logica.persona;


public class Domiciliario extends persona {
    private String direccion;
    private boolean vehiculoPropio;
    private boolean vehiculoEmpresarial;

    public Domiciliario(String nombre, String apellido, String ID, String celular, String direccion, boolean vehiculoPropio, boolean vehiculoEmpresarial) {
        super(nombre, apellido, ID, celular);
        this.direccion = direccion;
        this.vehiculoPropio = vehiculoPropio;
        this.vehiculoEmpresarial = vehiculoEmpresarial;
    }

    @Override
    public String toString() {
        return super.toString() + ", Dirección: " + direccion + ", Vehículo Propio: " + vehiculoPropio + ", Vehículo Empresarial: " + vehiculoEmpresarial;
    }
}






