
package Persistencia;

import Persistencia.Domiciliario;
import Persistencia.Cliente;
import Logica.Productos;


public class Pedido {
    private int numeroPedido;
    private Cliente cliente;
    private Productos[] productos;
    private Domiciliario domiciliario;
    private double costoDomicilio;

    public Pedido(int numeroPedido, Cliente cliente, Productos[] productos, Domiciliario domiciliario, double costoDomicilio) {
        this.numeroPedido = numeroPedido;
        this.cliente = cliente;
        this.productos = productos;
        this.domiciliario = domiciliario;
        this.costoDomicilio = costoDomicilio;
    }

    

    @Override
    public String toString() {
        return "Número de Pedido: " + numeroPedido + "\nCliente: " + cliente + "\nDomiciliario: " + domiciliario + "\nCosto del Domicilio: $" + costoDomicilio;
    }
}
